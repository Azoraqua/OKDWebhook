# OdysseyKingdom Webhook
A simple plugin to send webhook commands.